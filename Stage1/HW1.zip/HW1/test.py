from ExampleGen import gen_examples
from RuleGen import gen_rule_data

examples = gen_examples(1, 4)
prev, following = gen_rule_data(examples)

print('Examples:')
#print(examples)
print('\nCounts:')
print(prev.sort_values('Correct_Count'))

